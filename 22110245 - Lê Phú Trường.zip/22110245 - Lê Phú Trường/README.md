# Báo cáo lý thuyết và thực hành Giải tích số

Thư mục này chứa tất cả các tệp và thư mục cần thiết cho bài báo cáo. Dưới đây là mô tả chi tiết về từng thành phần trong kho lưu trữ.

## Cấu trúc thư mục

- **code/**: Thư mục này chứa tất cả các file code liên quan đến báo cáo Giải tích số bao gồm `.ipynb` và `.py`. Đảm bảo sắp xếp các tệp code đúng cách như trình bày trong phần báo cáo.

- **images/**: Thư mục này chứa tất cả các file ảnh được sử dụng trong báo cáo. Hình ảnh ở định dạng `.png`. Thư mục này được tham chiếu trong tệp LaTeX để đưa hình ảnh vào tài liệu.

- **numana.bib**: Tệp này là tệp BibTeX chứa tất cả các mục nhập thư mục, được sử dụng để quản lý các tài liệu tham khảo và trích dẫn trong tài liệu LaTeX.

- **Numerical Analysis.pdf**: Đây là phiên bản PDF được biên dịch của tài liệu LaTeX. Đây là đầu ra cuối cùng bao gồm tất cả nội dung, hình ảnh và tài liệu tham khảo.

- **Numerical Analysis.tex**: Đây là tệp LaTeX chính cho báo cáo. Nó bao gồm các hướng dẫn về cấu trúc, nội dung và định dạng cho tài liệu.

## Hướng dẫn

### Cập nhật `\graphicspath` trong LaTeX

Mặc dù tôi đã chạy thử và thành công với định dạng:
```latex
\graphicspath{{./images/}}
```

nhưng để đảm bảo LaTeX có thể tìm thấy hình ảnh trong thư mục `images/`, thầy/cô có thể cập nhật `\graphicspath` trong tệp `Numerical Analysis.tex`. Đây là cách thực hiện:

1. Mở tệp `Numerical Analysis.tex`.
2. Xác định vị trí lệnh `\graphicspath` và cập nhật, sẽ có dạng như sau:

    ```latex
    \graphicspath{{(your folder location)/images/}}
    ```

    Điều này yêu cầu LaTeX tìm kiếm hình ảnh trong thư mục `images/` nằm trong cùng thư mục với tệp `Numerical Analysis.tex`.

### Biên dịch tài liệu LaTeX

Để biên dịch tài liệu LaTeX và tạo tệp PDF, hãy làm theo các bước sau:

1. Đảm bảo bạn đã cài đặt bản phân phối LaTeX trên hệ thống của mình (ví dụ: TeX Live, MiKTeX).
2. Mở terminal hoặc dấu nhắc lệnh.
3. Điều hướng đến thư mục chứa tệp `Numerical Analysis.tex`.
4. Chạy lệnh sau để biên dịch tài liệu:

    ```sh
    pdflatex Numerical Analysis.tex
    ```

5. Nếu tài liệu của thầy/cô sử dụng `bibliography`, thầy/cô cũng có thể cần chạy các lệnh sau:

    ```sh
    bibtex Numerical Analysis
    pdflatex Numerical Analysis.tex
    pdflatex Numerical Analysis.tex
    ```

Điều này sẽ tạo ra tệp `Numerical Analysis.pdf` trong cùng thư mục.

## Liên hệ

Nếu có vấn đề nào về thư mục, thầy/cô có thể liên hệ với sinh viên thông qua email: [22110245@student.hcmus.edu.vn].
